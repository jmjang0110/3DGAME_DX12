#include "stdafx.h"
#include "CComponent.h"

CComponent::CComponent()
{

}

CComponent::~CComponent()
{

}

void CComponent::Init()
{
}

void CComponent::Update(float _fTimeElapsed)
{
}

void CComponent::FinalUpdate(float _fTimeElapsed)
{
}

void CComponent::UpdateShaderVariables()
{
}

void CComponent::Activate()
{
}

void CComponent::Deactivate()
{
}

bool CComponent::IsActive()
{
	return false;
}
